<?php
 
/**
 * @file
 * Contains \Drupal\myajaxtest\Controller\MyajaxTestController
 */
 
namespace Drupal\myajaxtest\Controller;
 
use Drupal\Core\Controller\ControllerBase;
 
/**
 * Controller routines for theme example routes.
 */
class AjaxMethods extends ControllerBase {
 
   /**
   * callajax
   * @return string
   */
  public function callajaopenimage(){

  }

}
