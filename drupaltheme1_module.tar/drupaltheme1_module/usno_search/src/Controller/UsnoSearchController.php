<?php

namespace Drupal\usno_search\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An usno_search controller.
 */
class UsnoSearchController extends ControllerBase {

  /**
   * Returns a render-able array for usno search page.
   */
  public function content() {
	 global $base_url;

   $folder = "/var/www/html/ncn_deploy1/";
 
  	$base_url_parts = parse_url($base_url);
  	$host = $base_url_parts['host'];

    $search_keyword = '';
    $search_results_arr = array();
    $previous_html = '';
    $page_html = '';
    $next_html = '';
    $warning_msg = '';

  	$keys = '';    
  	if( (isset($_GET['keys'])) && ($_GET['keys']!='') ){
      $keys = filter_input(INPUT_GET, 'keys', FILTER_SANITIZE_STRING);
  	}

    $search_keyword = trim($keys);    

    if( ($search_keyword!='') && ( strlen($search_keyword) >= 3) ){

      $database = \Drupal::database();

      $sql = '';
      $sql .= " SELECT nfd.nid,nfd.title,ua.alias,nb.body_value ";
      $sql .= " FROM node__body as nb ";
      $sql .= " INNER JOIN node_field_data as nfd ";
      $sql .= " on nb.entity_id = nfd.nid ";
      $sql .= " INNER JOIN url_alias as ua ";
      $sql .= " on concat( '/node/', nfd.nid ) = ua.source ";
      $sql .= " WHERE ";
      $sql .= " nb.body_value LIKE '%$search_keyword%' ";      
      $sql .= " OR ";
      $sql .= " nfd.title LIKE '%$search_keyword%' ";

      $query = $database->query($sql);
      $results = $query->fetchAll();

      $db_search_arr = array();
      $db_count = 0;
      if(is_array($results) && count($results)>0 ){
        foreach ($results as $res_key => $result) {
          $nid = $result->nid;
          $title = $result->title;
          $alias = $result->alias;
          $body_value = trim(strip_tags($result->body_value));
          $body_length = strlen($body_value);
          $search_keyword_pos = stripos($body_value , $search_keyword);

          $trim_content_length = 350;

          if($search_keyword_pos == 1 ){
            $start_dots = '';   
            $body_value = substr($body_value, 0, $search_keyword_pos );
          }else{
            if($body_length >= $trim_content_length ){
              $start_dots = '... ';
              //$body_value = substr($body_value, $search_keyword_pos-$trim_content_length );
              if( ( $body_length - $search_keyword_pos ) < ($trim_content_length) ) {
                //$body_value = substr($body_value, 0, $trim_content_length );
                $start_dots = '';
              }else{
                $body_value = substr($body_value, $search_keyword_pos );
              }
            }else{
              $start_dots = '';
            }
          }

          /**
           * Search Higlight and trim code starts
           */

          $seached_higlighted_str = str_ireplace($search_keyword, "<strong>$search_keyword</strong>", $body_value);

          /**
           * Search Higlight and trim code ends
           */

          if(strlen($seached_higlighted_str) >= $trim_content_length ){
            $seached_higlighted_str = $start_dots.substr($seached_higlighted_str, 0, $trim_content_length).' ...';
          }
      
          $db_search_arr[$db_count]['title'] = $title;
          $db_search_arr[$db_count]['url'] = $base_url.$alias;        
          $db_search_arr[$db_count]['seached_higlighted_str'] = $seached_higlighted_str;
          $db_search_arr[$db_count]['result_type'] = 'db_search';
          $db_count++;
        }
      }

      /**
       * File Array Process starts
       */

      $command = "grep -H -r --include \*.txt --include \*.html '$search_keyword' $folder  | cut -d: -f1 | sort --unique";
      $output = shell_exec($command);
      $oparray = preg_split('/\s+/', trim($output));      

      $grep_cmd_array = array();
      if(is_array($oparray)){
        $grep_cmd_array = $oparray;
      }

      //Find Command File Array Starts
      //$file_name_search_command = "find $folder -type f -iname $search_keyword";
      $file_name_search_command = "find $folder -iname $search_keyword*";
      $file_name_output = shell_exec($file_name_search_command);

      $filen_oparray = preg_split('/\s+/', trim($file_name_output));

      $file_cmd_array = array();
      if(is_array($filen_oparray)){
        $file_cmd_array = $filen_oparray;
      }

      //file search without extension
      $file_name_search_without_ext_command = "find $folder -iname $search_keyword.*";
      $file_without_ext_output = shell_exec($file_name_search_without_ext_command);

      $filen_without_ext_oparray = preg_split('/\s+/', trim($file_without_ext_output));


      $file_without_ext_cmd_array = array();
      if(is_array($filen_without_ext_oparray)){
        $file_without_ext_cmd_array = $filen_without_ext_oparray;
      }

      $find_cmd_merged_array = array_merge($file_cmd_array, $file_without_ext_cmd_array);

      $main_merged_file_array = array_unique(array_merge($find_cmd_merged_array, $grep_cmd_array));

      // array need to be replaced with the original preg searched result array
      $file_result_arr = $main_merged_file_array;

      if(is_array($file_result_arr) && count($file_result_arr) > 0 ){
        foreach ($file_result_arr as $file_res_key => $file_result ) {

          if( ($file_result) && ( $file_result!='') ){
            $replace_root_dir = str_replace('/var/www/html', '', $file_result );

            if(is_dir($file_result)) {

              $file_path_info = pathinfo($replace_root_dir);

              $filename = $file_path_info['filename'];
              $basename = $file_path_info['basename'];

              $base_64_encode_file_path = base64_encode($replace_root_dir);
              if(strtolower($filename) == strtolower('vgosDb') ){
                $base_64_encode_file_path = base64_encode($replace_root_dir.'/2019');
              }

              $file_url = $base_url.'/usnodocspath?file_name='.$filename.'&data='.$base_64_encode_file_path;
            } else {
              $file_path_info = pathinfo($replace_root_dir);

              $file_extension = $file_path_info['extension'];
              $filename = $file_path_info['filename'];
              $basename = $file_path_info['basename'];

              if($file_extension == 'txt'){
                $base_64_encode_file_path = base64_encode($replace_root_dir);
                $file_url = $base_url.'/usnodocspath?file_name='.$filename.'&single_data='.$base_64_encode_file_path;
              }else{
                $file_url = $base_url.$replace_root_dir;
              }
            }

            $db_search_arr[$db_count]['title'] = $basename;
            $db_search_arr[$db_count]['url'] = $file_url;        
            $db_search_arr[$db_count]['seached_higlighted_str'] = '';
            $db_search_arr[$db_count]['result_type'] = 'file_search';

            $db_count++;
          }
        }
      }




      /**
       * Pagination Code Starts
       */

        $search_results_arr = array();
        /////////////////////START OF ARRAY PAGINATION CODE/////////////////////

        $next = '';
        $previous = '';

        $url_with_search_keyword = $base_url.'/usno_search?keys='.$search_keyword;

        $array = $db_search_arr; // REPLACE $KEY WITH YOUR ARRAY VARIABLE      

        $page_no_request = '';
        if( (isset($_REQUEST['pageno']) && ( trim($_REQUEST['pageno']) != '') )){
          $page_no_request = filter_input(INPUT_GET, 'pageno', FILTER_SANITIZE_STRING);
        }

        $page = trim($page_no_request);

        $currentpage = isset($page) ? (integer)$page : 1;
        $numperpage = 10; //NUMBER OF RECORDS TO BE DISPLAYED PER PAGE

        $total = count($array);
        $numofpages = ceil($total / $numperpage); //TOTAL NUMBER OF PAGES

        if(isset($array))
        {
            if (($currentpage > 0) && ($currentpage <= $numofpages))
         {
            //STARTING LOOP FOR ARRAY DATA
            $start = ($currentpage-1) * $numperpage;
            for($i=$start;$i<=($numperpage+$start-1);$i++) {
                ///////////PLACE YOUR CODE HERE//////////////////////////
                if(isset($array[$i])){
                  $search_results_arr[] = $array[$i];
                }
                ////////////////////////////////////////////////////////
            }
         }
        }

        $previous_html = '';
        $next_html = '';

        if ($currentpage != 1) 
        { //GOING BACK FROM PAGE 1 SHOULD NOT BET ALLOWED
          $previous_page = $currentpage - 1;
          $previous = '<a href="'.$url_with_search_keyword.'&pageno='.$previous_page.'"> <</a> ';

          $previous_html .= '<li class="pager__item pager__item--first">';
          $previous_html .= '<a href="'.$url_with_search_keyword.'&pageno=1" title="Go to first page" rel="first">';
          $previous_html .= '<span class="visually-hidden">First page</span>';
          $previous_html .= '<span aria-hidden="true">‹‹ First</span>';
          $previous_html .= '</a>';
          $previous_html .= '</li>';

          $previous_html .= '<li class="pager__item pager__item--previous">';
          $previous_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$previous_page.'" title="Go to previous page" rel="prev">';
          $previous_html .= '<span class="visually-hidden">Previous page</span>';
          $previous_html .= '<span aria-hidden="true">‹ Previous</span>';
          $previous_html .= '</a>';
          $previous_html .= '</li>';
        }    
        $pages = '';
        $page_html = '';

        $max = 7;  //max no of links to be shown
        if($max >= $numofpages ){
          $max = $numofpages - 1;
        }

        if($page < $max){
          $sp = 1;
        }            
        elseif($page >= ($numofpages - floor($max / 2)) ){
          $sp = $numofpages - $max + 1;
        }
        elseif($page >= $max){
          $sp = $page  - floor($max/2);
        }

        // If the current page >= $max then show link to 1st page
        if($page > $max){
          $page_html .= '<li class="pager__item">';
          $page_html .= '<a href="'.$url_with_search_keyword.'&pageno=1" title="Go to page 1">';
          $page_html .= '<span class="visually-hidden">';
          $page_html .=  'page';
          $page_html .= '</span>1</a>';
          $page_html .= '</li>';
          if( $max != ( $numofpages - 1) ){
            $page_html .= '<li class="pager__item">';
            $page_html .=  ' ... ';
            $page_html .= '</li>';
          }
        }

        for($a = $sp; $a <= ($sp + $max -1);$a++)
        {
          if ($a == $currentpage){
            $pages .= $a .'</u> ';
          } 
          else{
            $pages .= '<a href="'.$url_with_search_keyword.'&pageno='.$a.'" >'. $a .'</a> ';
          }

            if($a > $numofpages){
              continue;
            }

          //if( $a - 1 !== 1 ){
          if($page == $a){
            $page_html .= '<li class="pager__item active_page">';
            $page_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$a.'" title="Go to page '.$a.'">';
            $page_html .= '<span class="visually-hidden">';
            $page_html .=  'page';
            $page_html .= '</span>'.$a.'</a>';
            $page_html .= '</li>';
          }else{
            $page_html .= '<li class="pager__item">';
            $page_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$a.'" title="Go to page '.$a.'">';
            $page_html .= '<span class="visually-hidden">';
            $page_html .=  'page';
            $page_html .= '</span>'.$a.'</a>';
            $page_html .= '</li>';
          }

        }

        if( $page <  ($numofpages - floor($max / 2)) ){
            if( $max != ( $numofpages - 1) ){
              $page_html .= '<li class="pager__item">';
              $page_html .=  ' ... ';
              $page_html .= '</li>';
            }

            $page_html .= '<li class="pager__item">';
            $page_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$numofpages.'" title="Go to page '.$numofpages.'">';
            $page_html .= '<span class="visually-hidden">';
            $page_html .=  'page';
            $page_html .= '</span>'.$numofpages.'</a>';
            $page_html .= '</li>';
        }

        $pages = substr($pages,0,-1); //REMOVING THE LAST COMMA (,)

        if ($currentpage != $numofpages) 
        { //GOING AHEAD OF LAST PAGE SHOULD NOT BE ALLOWED
          $next_page = $currentpage + 1;
          $next = ' <a href="'.$url_with_search_keyword.'&pageno='.$next_page.'"> ></a>';

          $next_html .= '<li class="pager__item pager__item--next">';
          $next_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$next_page.'" title="Go to next page" rel="next">';
          $next_html .= '<span class="visually-hidden">Next page</span>';
          $next_html .= '<span aria-hidden="true">Next ›</span>';
          $next_html .= '</a>';
          $next_html .= '</li>';

          $next_html .= '<li class="pager__item pager__item--last">';
          $next_html .= '<a href="'.$url_with_search_keyword.'&pageno='.$numofpages.'" title="Go to next page" rel="last">';
          $next_html .= '<span class="visually-hidden">Last page</span>';
          $next_html .= '<span aria-hidden="true">Last ››</span>';
          $next_html .= '</a>';
          $next_html .= '</li>';
        }

        /////////////////////END OF ARRAY PAGINATION CODE/////////////////////

    }else{
      if($search_keyword == ''){
        $warning_msg = 'Please enter some keywords.';
      }else{
        $warning_msg = 'You must include at least one keyword to match in the content. Keywords must be at least 3 characters.';
      }
    }

    \Drupal::service('page_cache_kill_switch')->trigger();

      return array(      
        '#theme' => 'usno_search-search',            
        '#base_url'  => $base_url,
        '#search_keyword' => $search_keyword,
        '#search_results_arr' => $search_results_arr,
        '#previous' => $previous_html,
        '#pages' => $page_html,
        '#next' => $next_html,
        '#warning_msg' => $warning_msg,
      );
  }

}