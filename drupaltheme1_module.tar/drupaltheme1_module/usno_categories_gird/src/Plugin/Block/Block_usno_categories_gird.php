<?php
namespace Drupal\usno_categories_gird\Plugin\Block;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "usno_categories_gird",
 *   admin_label = @Translation("usno categories gird"),
 * )
 */
class Block_usno_categories_gird extends BlockBase {
    /**
     * {@inheritdoc}
     */
    public function build() {
        $this->custom_gird_view();
        $this->getCacheMaxAge();
        return ['#markup' => $this->t($this->custom_gird_view()), ];
    }
    public function getCacheMaxAge() {
        return 0;
    }
    /**
     * {@inheritdoc}
     */
    protected function blockAccess(AccountInterface $account) {
        return AccessResult::allowedIfHasPermission($account, 'access content');
    }
    /**
     * {@inheritdoc}
     */
    public function blockForm($form, FormStateInterface $form_state) {
        $config = $this->getConfiguration();
        return $form;
    }
    /**
     * {@inheritdoc}
     */
    public function blockSubmit($form, FormStateInterface $form_state) {
        $this->configuration['my_block_settings'] = $form_state->getValue('my_block_settings');
    }
    public function custom_gird_view() {
        $html = "";
        $current_user = \Drupal::currentUser();
        $roles = $current_user->getRoles();
        $variables_usno_categories_gird['edit_mode'] = 0;
        if ($roles[0] == "authenticated") {
            if ($roles[1] == "administrator") {
                $variables_usno_categories_gird['edit_mode'] = 1;
            }
        }
        $current_path = \Drupal::service('path.current')->getPath();
        $current_path_url1 = \Drupal::service('path.alias_manager')->getAliasByPath($current_path);
        $current_path_url = trim($current_path_url1);
        $s = $f_type = "";
        $s = "data_products";
        $f_type = "field_data_product_image";
        $f_link_title_type = "field_data_product_title";
        $f_link_custom_page_url_type = "field_product_custom_page_url";
        if ($current_path_url == "/ivs-analysis-center") {
            $s = "ivs_analysis_center";
            $f_type = "field_ivs_analysis_center_image";
            $f_link_title_type = "";
        }
        if ($current_path_url == "/source-structure-analysis-center") {
            $s = "source_structure_analysis_center";
            $f_type = "field_s_s_analysis_center_";
            $f_link_title_type = "";
        }
        if ($current_path_url == "/iasc") {
            $s = "iasc_1";
            $f_type = "field_iasc_1_image";
            $f_link_title_type = "";
        }
        $query = \Drupal::database()->select('node', 'n');
        $query->fields('n', ['nid']);
        $query->condition('n.type', $s);
        $nids_data_products = $query->execute()->fetchAll();
        // get and set values from content type to variable
        if (!empty($nids_data_products)) {
            $variables_usno_categories_gird['data_products'] = array();
            foreach ($nids_data_products as $val) {
                $nids_data_products_node2 = Node::load($val->nid);
                $alias = "";
                $text_title = $nids_data_products_node2->get('title')->getValue();
                $discription = $nids_data_products_node2->get('body')->getValue();
                $alias = \Drupal::service('path.alias_manager')->getAliasByPath('/node/' . $val->nid);
                $link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'];
                if (isset($alias) && $alias != "") {
                    $setbase_path = "";
                    if (base_path() != "") {
                        $setbase_path = base_path();
                    }
                    $alias1 = $link . $setbase_path . $alias;
                } else {
                    $alias1 = "#";
                }
                $field_custom_link_title = "Read More";
                if ($f_link_title_type != "") {
                    $field_custom_link_title1 = $nids_data_products_node2->get($f_link_title_type)->getValue();
                    $field_custom_link_title = $field_custom_link_title1 ? $field_custom_link_title1[0]['value'] : "Read More";
                }
                $field_custom_page_url1 = $nids_data_products_node2->get($f_link_custom_page_url_type)->getValue();
                $custom_page_url = $field_custom_page_url1 ? $field_custom_page_url1[0]['value'] : "";
                if ($custom_page_url && $custom_page_url != "") {
                    $alias1 = $custom_page_url;
                }
                $img = "";
                if ($f_type) {
                    $img = $nids_data_products_node2->get($f_type)->getValue();
                }
                $file = "";
                if (is_array($img) && isset($img[0]['target_id'])) {
                    $file = \Drupal\file\Entity\File::load($img[0]['target_id']);
                }
                $fileurl = "";
                if ($file) {
                    $fileurl = $file->url();
                }
                $variables_usno_categories_gird['data_products'][] = array('text_data_product_title' => $text_title ? $text_title[0]['value'] : "", 'text_data_product_discription' => customBreakLongText($discription ? $discription[0]['value'] : "", 60, 145), 'alias' => $alias1, 'custom_readmorelink' => $field_custom_link_title, 'data_product_img_src' => $fileurl, 'custom_quiedit_url' => base_path() . "node/" . $val->nid . "/edit?destination=" . base_path() . $current_path_url, 'custom_delete_url' => base_path() . "node/" . $val->nid . "/delete?destination=" . base_path() . $current_path_url,);
            }
        } //data_product_page loop end here
        $html = " ";
        if (isset($variables_usno_categories_gird['data_products'])) {
            $html.= '<div class=" " style=""><div class="row">';
            $i = 1;
            foreach ($variables_usno_categories_gird['data_products'] as $data_product) {
                $html.= '<div class="col-md-3 col-sm-6 col-xs-12"><div class="third_sec">';
                if ($variables_usno_categories_gird['edit_mode'] && $variables_usno_categories_gird['edit_mode'] == 1) {
                    $html.= '<div class="custom-edit">
    <div  class="contextual custom_edit_class" role="form" style="margin-top: 40px;">
    <button class="trigger focusable visually-hidden my-button" type="button" aria-pressed="false">Open options</button>
    <ul class="contextual-links" hidden="">';
                    $html.= ' 
    <li class="block-contentblock-edit"><a href="' . $data_product['custom_quiedit_url'] . '">Edit</a></li>
    <li> <a href="' . $data_product['custom_delete_url'] . '">Delete</a></li>
    </ul>
    </div>
    </div>';
                }
                $html.= '<span class="data_products_upper_title_span">';
                $html.= '<a href="' . $data_product['alias'] . '">' . $data_product['custom_readmorelink'] . '</a>';
                $html.= '</span>';
                $html.= '<a href="' . $data_product['alias'] . '"><img src="' . $data_product['data_product_img_src'] . '" class="img-responsive" alt="' . $data_product['text_data_product_title'] . '"></a>';
                $html.= '<div class="data_product_third_sec_text"><div class="text-center">
    <p class="data_product_third_text_heading">';
                $html.= '' . $data_product['text_data_product_title'] . '</p>';
                $html.= '<p class="data_product_cols_text">' . $data_product['text_data_product_discription'] . '</p>';
                $html.= '</div></div></div></div>';
            }
            $html.= '
    </div>
    </div>
    ';
        }
        return $html;
    }
}
