<?php

namespace Drupal\usno_catelog\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;

/**
 * Provides a block with usno catelog only.
 *
 * @Block(
 *   id = "usno_catelog",
 *   admin_label = @Translation("usno catelog"),
 * )
 */
class Block_usno_catelog extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    // Create data for services_catalogue
    
    return [
      '#markup' => $this->t($this->custom_catelog_view()),
    ];
  }


  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['my_block_settings_usno_catelog'] = $form_state->getValue('my_block_settings_usno_catelog');
  }
  public function custom_catelog_view(){
    global $base_url;
    // Get from DB nids of content type slider_image
    $html="";
 $current_user = \Drupal::currentUser();
 $roles = $current_user->getRoles();
 $variables_usno_catelog['edit_mode']=0;
if($roles[0] == "authenticated"){
  if($roles[1] == "administrator"){ 
     $variables_usno_catelog['edit_mode']=1;
  }
 }
    $current_path = \Drupal::service('path.current')->getPath();
   $current_path_url1 = \Drupal::service('path.alias_manager')->getAliasByPath($current_path);
   $current_path_url=trim($current_path_url1);
   
    // Create data for services_catalogue
    // Get from DB nids of content type slider_image
    $query = \Drupal::database()->select('node', 'n');
    $query->fields('n', ['nid']);
    $query->condition('n.type', 'services_catalogue');
    //$query->condition('n.status', 1);

    $nids_services_catalogue = $query->execute()->fetchAll();
    $variables_usno_catelog['services_catalogue'] = array();
      
    

    // get and set values from content type to variable
    if(!empty($nids_services_catalogue)){
    foreach ($nids_services_catalogue as $val) {
      $services_catalogue_node = Node::load($val->nid);
      
      
       $text_title = $services_catalogue_node->get('field_services_title')->getValue();
     // $text = $node->get('body')->getValue();
      $img = $services_catalogue_node->get('field_services_image')->getValue();
      $field_services_link = $services_catalogue_node->get('field_services_link')->getValue(); 
     $file ="";
    if(is_array($img) && $img[0]['target_id'] !=""){
      $file = \Drupal\file\Entity\File::load($img[0]['target_id']);
     }
    
     $fileurl="";
     if($file){
     $fileurl=$file->url();
     }
      $variables_usno_catelog['services_catalogue'][] = array(
        'text_service_title' =>$text_title?$text_title[0]['value'] :"",
         'service_img_src'=>$fileurl,
          'service_services_link' =>$field_services_link?$field_services_link[0]['value'] :"",
         'custom_quiedit_url'=> base_path()."node/".$val->nid."/edit?destination=".base_path().$current_path_url,
        'custom_delete_url'=> base_path()."node/".$val->nid."/delete?destination=".base_path().$current_path_url,  
      );
    }
   }//services end here



    
   $html=" ";
   if(isset($variables_usno_catelog['services_catalogue'])){
  $html.='  
  <section id="home_second">
   <div class="container-fluid">
    <div class="row collag_img_margin">
      <div class="col-md-8 col-sm-8 col-xs-12 collag_img_padding">
  ';
      $i=1;
      //{% for data_product in data_product_page.data_products %}    
      foreach ($variables_usno_catelog['services_catalogue'] as $service_catalogue) {
        # code...
           
        switch ($i) {
          case '1':
            # code...
          $customclass="services_collag_img services_collag_long_img 1";
          $image_class= "collag_img_big 1";
          break;
          case '2':
            # code...
          $customclass="services_collag_img_two 2";
          $image_class= "collag_img_sall 2";
          break;
            case '3':
            # code...
          $customclass="services_collag_img 3";
          $image_class= "collag_img_small 3";
         
            break;
            case '4':
            # code...
          $customclass="services_collag_img_two 4";
          $image_class= "collag_img_sall 4";
         
            break;  
          default:
            # code...
          $customclass="NA ";
          $image_class= "na";
            break;
        }
       

        $html.='<div class="'.$customclass.'">
        ';
            //EDIT MODE START
          if($variables_usno_catelog['edit_mode'] && $variables_usno_catelog['edit_mode']==1){ 
            $html.='<div class="custom-edit">
            <div  class="contextual " role="form" style="margin-top: 40px;">
            <button class="trigger focusable visually-hidden my-button" type="button" aria-pressed="false">Open '.'usno catelog'/*$service_catalogue['text_service_title']*/ .' options</button>
            <ul class="contextual-links" hidden="">';
            $html.='<li class="block-contentblock-edit"><a href="'.$service_catalogue['custom_quiedit_url'].'">Edit</a></li>
              <li> <a href="'.$service_catalogue['custom_delete_url'].'">Delete</a></li>
              </ul>
              </div>
             </div>';
          }
            //EDIT MODE CLOSE

        $html.='<img src="'.$service_catalogue['service_img_src'].'" alt="'.strip_tags($service_catalogue['text_service_title']).'" class="img-responsive '.$image_class.'">';
       $html.='<div class="services_collag_img_text"><a href="'.$base_url."/".$service_catalogue['service_services_link'].'" style="color: white;">
            '.$service_catalogue['text_service_title'].'
          </a></div>';
        $html.= '</div>';
        $i=$i+1;
        if($i>4){$i=1;}
      }
            $html.='
              </div>  
            </div>
        </div>
        </section>
            ';
    }
    return $html;
  }
}