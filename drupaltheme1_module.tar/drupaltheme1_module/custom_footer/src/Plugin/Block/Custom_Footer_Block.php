<?php

namespace Drupal\custom_footer\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;
use Drupal\file\Plugin\Core\Entity\FileInterface;
use \Drupal\Core\Url;
use \Drupal\file\Entity\File;


/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "custom_footer",
 *   admin_label = @Translation("custom_footer"),
 * )
 */
class Custom_Footer_Block extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#markup' => $this->t($this->my_ft_block()),
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['my_block_settings'] = $form_state->getValue('my_block_settings');
  }
  public function my_ft_block()
  {  
    global $base_url;

     // $all_content_types = NodeType::loadMultiple();
     //  foreach ($all_content_types as $machine_name => $content_type) {
     //    $content_type_array[] = $machine_name;
     //  }
    // if(in_array('fotter_contents',$content_type_array))
    // {
            $query = \Drupal::database()->select('node', 'n');
            $query->fields('n', ['nid']);
            $query->condition('n.type', 'fotter_contents');
            $query->orderBy('nid', 'ASC');
            $query->range(0, 1);
            $career_path = $query->execute()->fetchAll();
            foreach ($career_path as $val) {
                $node = Node::load($val->nid);
                $body = $node->get('body')->getValue();
                $field_disclaimer_link = $node->get('field_disclaimer_link')->getValue();
                $field_disclaimer_title = $node->get('field_disclaimer_title')->getValue();
                $field_privacy_link = $node->get('field_privacy_link')->getValue();
                $field_privacy_title = $node->get('field_privacy_title')->getValue();             
              
              }
    // }
    $html='<section class="home_forth">
                   <div class="container">
                      <div class="row">
                         <div class="col-md-6 col-sm-6 col-xs-12">
                            <div style="text-align:center;">
                            <p><a href="'.$base_url."/".$field_privacy_link[0]['value'].'">'.$field_privacy_title[0]['value'].'</a></p>
                            </div>
                          </div>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                           <div style="text-align:center;">
                              <p class="myclass"><a href="'.$base_url."/".$field_disclaimer_link[0]['value'].'">'.$field_disclaimer_title[0]['value'].'</a></p>
                              </div>
                         </div>
                      </div>
                   </div>
            </section>';
    $html .='<section id="footer">
             <footer class="footer {{ container }}" role="contentinfo">
               '.$body[0]['value'].'
             </footer>
            </section>';

    return $html;    

  }
}