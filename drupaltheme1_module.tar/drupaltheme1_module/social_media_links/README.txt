DESCRIPTION
===========
The modules provides a configurable block that display links (icons) to your
profiles on various popular networking sites.

INSTALLATION
============
1. Install as usual, see https://www.drupal.org/docs/8/extending-drupal-8/installing-contributed-modules-find-import-enable-configure for further information.
2. The module has no special configuration. All settings are available in the
   block settings:
   /admin/structure/block

INCLUDED ICON SETS
==================
The module contains a icon set, that the module is ready for use immediately
after the installation.

MAINTAINER
==========
- cbeier (Christian Beier)
