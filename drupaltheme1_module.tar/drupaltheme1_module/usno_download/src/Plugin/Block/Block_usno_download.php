<?php

namespace Drupal\usno_download\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "usno_usno_download",
 *   admin_label = @Translation("show file block"),
 * )
 */
class Block_usno_download extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {

    $file_path_param = '';
    if($_GET && isset($_GET['usno_open_file_path'])){
      $file_path_param = $_GET['usno_open_file_path'];
    }else if($_GET && isset($_GET['source_path'])){
      $file_path_param = $_GET['source_path'];
    }else if($_GET && isset($_GET['oag_file'])){
      $file_path_param = $_GET['oag_file'];
    }else if($_GET && isset($_GET['openhtml_file'])){
      $file_path_param = $_GET['openhtml_file'];
    }else if($_GET && isset($_GET['source_file'])){
      $file_path_param = $_GET['source_file'];
    }else if($_GET && isset($_GET['single_data'])){
      $file_path_param =  base64_decode($_GET['single_data']);
    }else if($_GET && isset($_GET['data'])){
      $file_path_param = base64_decode($_GET['data']);
    }

    $filtered_file_path = $file_path_param;

    if (strpos($file_path_param, 'usno_files/usno_wds') !== false) {
      $filtered_file_path =str_replace("/usno_files/usno_wds","/ncn_deploy1/wds",$file_path_param);
    }else if(strpos($file_path_param, 'usno_files/usno_adeop') !== false){
      $filtered_file_path =str_replace("/usno_files/usno_adeop","/ncn_deploy1/ADEOP",$file_path_param);
    }    

    $explode_path = explode("/",$file_path_param);

    $view_files = 'no';
    if(is_array($explode_path) && count($explode_path)>1 ){
      if($explode_path[1] == 'ncn_deploy1' || $explode_path[1] == 'usno_files'){
        $view_files = 'yes';
      }
    }else if($_GET && isset($_GET['oag_file'])){
      $view_files = 'yes';
    }
    
    if(  $view_files == 'no'){
      $content_file_txt_html = "<div class='text-center' style='margin-top: 50px;'><p><b>File Not Found.<b></p></div>";
      return [
        '#markup' => $this->t($content_file_txt_html),
      ];
    }


    $file_table_html=" ";
    $content_file_txt_html=" ";
    $link= "";
    $static_folder_path="";
    $static_mount_folder_path="/var/www/html";
    
    if($_GET && isset($_GET['usno_open_file_path'])){
        //open a file  redirect path
        $openfile_path=$static_mount_folder_path.$_GET['usno_open_file_path'];
        $linkopenfile_path=$openfile_path;
        $handle = 1;
        $file_open=base64_encode($openfile_path);
        $phpfile_open_link=$link.$static_folder_path."showfile.php?usnofileopen=".$file_open;
        if($handle==1){
          echo '<script type="text/javascript">
          var linkpath= "'.$phpfile_open_link.'"; 
          window.location.href = linkpath;
          </script>';
        }else{
          return [
          '#markup' => $this->t($openfile_path ."<P>File not found </P>"),
          ];
        }
    }  

    if( ($_GET && isset($_GET['source_path'])) || ($_GET && isset($_GET['data'])) ){
      $THE_PATTERN = $filtered_file_path; //$_GET['source_path'];
      $file_table_html=" ";                      
      $file_table_html.='<iframe src="'.$link.$static_folder_path.'index2.php?source_path='.$THE_PATTERN.'" style="BORDER: NONE; width: 100%; min-height:500px;"></iframe>';

      return [
        '#markup' => $this->t($file_table_html),
      ];
    }

    if( ($_GET && isset($_GET['oag_file'])) || ($_GET && isset($_GET['source_file'])) || ($_GET && isset($_GET['single_data'])) ){

      $content_file_txt_html.="<BR/>";
      

      if( isset($_GET['source_file']) || isset($_GET['single_data']) ){
        $theurlfile= $filtered_file_path; //$_GET['source_file'];

      $content_file_txt_html.='<div class="iframe_loader_div"></div>';
      $content_file_txt_html.='<div class="files_search_btn_container">';
      $content_file_txt_html.='<div class="files_search_btn_wrapper">';
      $content_file_txt_html.='<input type="text" id="searchedText" value="" placeholder="Search Here" autocomplete="off">';
      $content_file_txt_html.='<a href="javascript:searchText();" class="btn">Search</a>';
      $content_file_txt_html.='</div>';
      $content_file_txt_html.='</div>';
      
      $content_file_txt_html.='<div class="download_btn_wrapper">';
      $content_file_txt_html.='<a href="download.php?filedownload='.base64_encode(urlencode($static_mount_folder_path.$theurlfile)).'" class="btn btn-default btn_download_sticky" >Download</a>';
      $content_file_txt_html.='</div>';


        $content_file_txt_html.='<iframe class="commonIframeCssClass" id="textIframe" src="'.$link.$static_folder_path.'showtxthtml.php?source_path='.$theurlfile.'"></iframe>';
      }
      if(isset($_GET['oag_file'])){

        //*******************//
        $link1 = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 
              "https" : "http") . "://" . $_SERVER['HTTP_HOST'];
        $absulte_file_path=$link1.$static_mount_folder_path."/ncn_deploy1/wds/unpublished";

        $absulte_file_path1=$static_mount_folder_path."/ncn_deploy1/wds/unpublished";
        $oag_header_file_path=$static_mount_folder_path."/ncn_deploy1/wds/unpublished/oag_head.txt";

        $oag_file_name = $_GET['oag_file'];

        $oag_file_name_array=explode("_", $oag_file_name);

        $oag_file_text_name=$oag_file_name_array[0];
        $oag_file_text_number=$oag_file_name_array[1];

        if(is_numeric($oag_file_text_number)){
        $file_pattern_path= $oag_file_text_name ."_supp" .$oag_file_text_number.'.txt';
        }else{
        $file_pattern_path= $oag_file_text_name ."_".$oag_file_text_number.'.txt';
        }
        $downloadfile=$absulte_file_path1.'/'.$file_pattern_path;
        //*******************//  

        $theurlfile = $_GET['oag_file'];

        $content_file_txt_html.='<div class="iframe_loader_div"></div>';
        $content_file_txt_html.='<div class="files_search_btn_container">';
        $content_file_txt_html.='<div class="files_search_btn_wrapper">';
        $content_file_txt_html.='<input type="text" id="searchedText" value="" placeholder="Search Here" autocomplete="off">';
        $content_file_txt_html.='<a href="javascript:searchText();" class="btn">Search</a>';
        $content_file_txt_html.='</div>';
        $content_file_txt_html.='</div>';

        $content_file_txt_html.='<div class="download_btn_wrapper">';
        $content_file_txt_html.='<a href="download.php?filedownload='.base64_encode(urlencode($downloadfile)).'" class="btn btn-default btn_download_sticky" >Download</a>';
        $content_file_txt_html.='</div>';
        $content_file_txt_html.='<iframe class="commonIframeCssClass" src="'.$link.$static_folder_path.'index_oag.php?oag_file='.$theurlfile.'"></iframe>';
      }

      $field_side_menu_link = 'wds-page-side-menu';
      $side_menu_html = get_side_menu_html_by_menu_id($field_side_menu_link);
      
      $render_html = '';
      $render_html .='<section class="file_viewer_page_content side_menu_page_body_content">';
      $render_html .='<input type="hidden" id="file_side_menu" value="yes">';
      $render_html .='<div class="file_viewer_page_side_nav sidemenu_page_sidenav col-md-4 col-sm-12 col-xs-12">';
      $render_html .= $side_menu_html;
      $render_html .='</div>';
      $render_html .='<div class="file_viewer_page_content_main sidenav_page_content_main col-md-8 col-sm-12 col-xs-12">';
      $render_html .='<div class="file_viewer_page_content_inner body_content_inner">';
      $render_html .=$content_file_txt_html;
      $render_html .='</div>';
      $render_html .='</div>';
      $render_html .='</section>';

      return [
        '#markup' => $this->t($render_html),
      ];      

      /*return [
        '#markup' => $this->t($content_file_txt_html),
      ];*/
    }

  
    if( $_GET && isset($_GET['openhtml_file'])){
    if(isset($_GET['openhtml_file'])){
        $theurlfile=$static_mount_folder_path.$_GET['openhtml_file'];
        //$content_file_txt_html="cc:-----" .$theurlfile;
      if(file_exists($theurlfile))
      {
       //include $theurlfile;
      $content_file_txt_html.='<iframe class="commonIframeCssClass" src="t.php"></iframe>';
      }
      else
      {
      $m='Opps! File not found. Please check the path again';
      $content_file_txt_html.=$m;
      }
        
      }
      return [
        '#markup' => $this->t($content_file_txt_html),
      ];
    }  
  
}
  public function getCacheMaxAge() {
    return 0;
  }
  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['my_block_settings_download2'] = $form_state->getValue('my_block_settings_download2');
  }
}