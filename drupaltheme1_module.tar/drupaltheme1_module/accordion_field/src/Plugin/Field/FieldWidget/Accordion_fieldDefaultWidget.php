<?php

namespace Drupal\accordion_field\Plugin\Field\FieldWidget;

use Drupal;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Plugin implementation of the 'Accordion_fieldDefaultWidget' widget.
 *
 * @FieldWidget(
 *   id = "Accordion_fieldDefaultWidget",
 *   label = @Translation("Accordion_field select"),
 *   field_types = {
 *     "Accordion_field"
 *   }
 * )
 */
class Accordion_fieldDefaultWidget extends WidgetBase {

  /**
   * Define the form for the field type.
   * 
   * Inside this method we can define the form used to edit the field type.
   * 
   * Here there is a list of allowed element types: https://goo.gl/XVd4tA
   */
  public function formElement(
    FieldItemListInterface $items,
    $delta, 
    Array $element, 
    Array &$form, 
    FormStateInterface $formState
  ) {

    // accordion_fieldimage 
    $element['accordion_fieldimage'] = [
      '#type' => 'textfield',
      '#title' => t('Title'),

      // Set here the current value for this field, or a default value (or 
      // null) if there is no a value
      '#default_value' => isset($items[$delta]->accordion_fieldimage) ? 
          $items[$delta]->accordion_fieldimage : null,

      '#empty_value' => '',
      '#placeholder' => t('Enter Title'),
    ];
    
    // accordion_fieldtext
    $element['accordion_fieldtext'] =[
      '#type' => 'text_format',
      '#title' =>  t('Content'),
      // '#required' => TRUE,
      '#default_value' => isset($items[$delta]->accordion_fieldtext) ? json_decode($items[$delta]->accordion_fieldtext)->value : '',
      '#empty_value' => '',
      '#format' => isset($items[$delta]->accordion_fieldtext) ? 
      json_decode($items[$delta]->accordion_fieldtext)->format : 'full_html',
      '#base_type' => 'textarea',
    ];
    //accordion_url    
     $element['accordion_url'] = [
      '#type' => 'textfield',
      '#title' => t('Url'),

      // Set here the current value for this field, or a default value (or 
      // null) if there is no a value
      '#default_value' => isset($items[$delta]->accordion_url) ? 
          $items[$delta]->accordion_url : null,

      '#empty_value' => '',
      '#placeholder' => t('Enter url'),
    ];
    //accordion_isfolder
    $element['accordion_isfolder'] = [
      '#type' => 'checkbox',
      '#title' => t('Url'),

      // Set here the current value for this field, or a default value (or 
      // null) if there is no a value
      '#default_value' => isset($items[$delta]->accordion_isfolder) ? 
          $items[$delta]->accordion_isfolder : null,

      '#empty_value' => '',
      '#placeholder' => t('Enter accordion_isfolder'),
    ];
    return $element;
  }

  public function massageFormValues(array $values, array $form, FormStateInterface $form_state) {
    foreach($values as $index => $value) {
        $values[$index]['accordion_fieldtext'] = json_encode($value['accordion_fieldtext']);
    }

    return $values;
}

} // class