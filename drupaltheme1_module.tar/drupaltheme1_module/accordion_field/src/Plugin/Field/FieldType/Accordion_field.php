<?php

namespace Drupal\accordion_field\Plugin\Field\FieldType;

use Drupal\Core\Field\FieldItemBase;
use Drupal\Core\TypedData\DataDefinition;
use Drupal\Core\Field\FieldStorageDefinitionInterface as StorageDefinition;

/**
 * Plugin implementation of the 'accordion_field ' field type.
 *
 * @FieldType(
 *   id = "accordion_field",
 *   label = @Translation("accordion_field"),
 *   description = @Translation("Stores Custom Accordion."),
 *   category = @Translation("Custom"),
 *   default_widget = "Accordion_fieldDefaultWidget",
 *   default_formatter = "Accordion_fieldDefaultFormatter"
 * )
 */
class Accordion_field extends FieldItemBase {

  /**
   * Field type properties definition.
   * 
   * Inside this method we defines all the fields (properties) that our 
   * custom field type will have.
   * 
   * Here there is a list of allowed property types: https://goo.gl/sIBBgO
   */
  public static function propertyDefinitions(StorageDefinition $storage) {

    $properties = [];

    $properties['accordion_fieldimage'] = DataDefinition::create('string')
      ->setLabel(t('Title'));

    $properties['accordion_fieldtext'] = DataDefinition::create('string')
      ->setLabel(t('Content'));
    $properties['accordion_url'] = DataDefinition::create('string')
      ->setLabel(t('Url'));
    $properties['accordion_isfolder'] = DataDefinition::create('string')
      ->setLabel(t('isfolder'));

      
    return $properties;
  }

  /**
   * Field type schema definition.
   * 
   * Inside this method we defines the database schema used to store data for 
   * our field type.
   * 
   * Here there is a list of allowed column types: https://goo.gl/YY3G7s
   */
  public static function schema(StorageDefinition $storage) {

    $columns = [];
    $columns['accordion_fieldimage'] = [
      'type' => 'varchar',
      'length' => 256,
      'not null' => FALSE,
    ];
    $columns['accordion_fieldtext'] = [
      'type' => 'text',
      'size' => 'big',
      'not null' => FALSE,
    ];
    $columns['accordion_url'] = [
      'type' => 'varchar',
      'length' => 256,
      'not null' => FALSE,
    ];
    //accordion_isfolder
     $columns['accordion_isfolder'] = [
      'type' => 'varchar',
      'length' => 256,
      'not null' => FALSE,
    ];
    return [
      'columns' => $columns,
      'indexes' => [],
    ];
  }

  /**
   * Define when the field type is empty. 
   * 
   * This method is important and used internally by Drupal. Take a moment
   * to define when the field fype must be considered empty.
   */
  public function isEmpty() {

    $isEmpty = 
      empty($this->get('accordion_fieldimage')->getValue()) &&
      empty($this->get('accordion_fieldtext')->getValue()) &&
      empty($this->get('accordion_url')->getValue());
    return $isEmpty;
  }

} // class
