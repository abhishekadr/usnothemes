<?php

namespace Drupal\accordion_field\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\FormatterBase;
use Drupal;

/**
 * Plugin implementation of the 'AddressDefaultFormatter' formatter.
 *
 * @FieldFormatter(
 *   id = "Accordion_fieldDefaultFormatter",
 *   label = @Translation("accordion_field"),
 *   field_types = {
 *     "accordion_field"
 *   }
 * )
 */
class Accordion_fieldDefaultFormatter extends FormatterBase {

  /**
   * Define how the field type is showed.
   * 
   * Inside this method we can customize how the field is displayed inside 
   * pages.
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {

    $elements = [];
    foreach ($items as $delta => $item) {
      $elements[$delta] = [
        '#type' => 'markup',
        '#markup' => $item->accordion_fieldimage . ', ' . $item->accordion_fieldtext.', '. $item->accordion_url .','. $item->accordion_isfolder
      ];
    }

    return $elements;
  }
  
} // class