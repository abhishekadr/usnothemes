<?php

namespace Drupal\usno_subscriber\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class SubcriberdataController.
 *
 * @package Drupal\usno_subscriber\Controller
 */
class SubcriberdataController extends ControllerBase {

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('This page contain all inforamtion about my data ')
    ];
  }

  public function add_s(){
    /***
     * Catcha Code Starts
     */

    $tp_contact_first_name;$tp_contact_last_name;$tp_contact_email;$tp_contact_phone;$tp_contact_question;$captcha;

    $tp_contact_first_name = filter_input(INPUT_POST, 'tp_contact_first_name', FILTER_SANITIZE_STRING);
    $tp_contact_last_name = filter_input(INPUT_POST, 'tp_contact_last_name', FILTER_SANITIZE_STRING);
    $tp_contact_email = filter_input(INPUT_POST, 'tp_contact_email', FILTER_VALIDATE_EMAIL);
    $tp_contact_phone = filter_input(INPUT_POST, 'tp_contact_phone', FILTER_SANITIZE_STRING);
    $tp_contact_question = filter_input(INPUT_POST, 'tp_contact_question', FILTER_SANITIZE_STRING);
    $captcha = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);

    if(!$captcha){
      echo '<h2>Please check the the captcha form.</h2>';
      exit;
    }
    $secretKey = theme_get_setting('google_recaptcha_secret_key');
    $ip = $_SERVER['REMOTE_ADDR'];

    // post request to server
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = array('secret' => $secretKey, 'response' => $captcha);

    $options = array(
      'http' => array(
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data)
      )
    );
    $context  = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $responseKeys = json_decode($response,true);
    header('Content-type: application/json');
    if($responseKeys["success"]) {
      echo json_encode(array('success' => 'true'));
    } else {
      echo json_encode(array('success' => 'false'));
    }

     /**
      * Captcha Code Ends
      */

    $crdate = date('Y-M-d h:i:s');
    $field  = array(
                'first_name' => $tp_contact_first_name,
                'last_name' => $tp_contact_last_name,
                'email' =>  $tp_contact_email,
                'phone' => $tp_contact_phone,
                'question' => $tp_contact_question,
                'is_verify' => "No",
                'crdate' => $crdate,
              );

    $query = \Drupal::database();
    $query ->insert('usno_subscriber')
          ->fields($field)
          ->execute();
  

    $to = \Drupal::config('system.site')->get('mail');

    if($to != ''){
      $msg = '';
      $msg .= '<div><strong>First Name</strong> : <b>'.$tp_contact_first_name.'</b> </div> <br>';
      $msg .= '<div><strong>Last Name</strong> : <b>'.$tp_contact_last_name.'</b> </div> <br>';
      $msg .= '<div><strong>Email </strong> : <b>'.$tp_contact_email.'</b> </div> <br>';
      $msg .= '<div><strong>Phone</strong> : <b>'.$tp_contact_phone.'</b> </div> <br>';
      $msg .= '<div><strong>Question</strong> : <b>'.$tp_contact_question.' </b> </div> ';
      
      $params = array();
      $params['subject'] = "Contact Us Message from ".$tp_contact_email;
      $params['body'][] = $msg;
      $account = \Drupal::currentUser();

      \Drupal::service('plugin.manager.mail')->mail('smtp', 'smtp-test', $to, $account->getPreferredLangcode(), $params);
    }

    //print_r($d);
    exit();
  }

}
