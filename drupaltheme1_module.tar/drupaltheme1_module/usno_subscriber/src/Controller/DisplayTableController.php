<?php

namespace Drupal\usno_subscriber\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\usno_subscriber\Controller
 */
class DisplayTableController extends ControllerBase {


  public function getContent() {
    // First we'll tell the user what's going on. This content can be found
    // in the twig template file: templates/description.html.twig.
    // @todo: Set up links to create nodes and point to devel module.
    $build = [
      'description' => [
        '#theme' => 'usno_subscriber_description',
        '#description' => 'foo',
        '#attributes' => [],
      ],
    ];
    return $build;
  }

  
  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    /**return [
      '#type' => 'markup',
      '#markup' => $this->t('Implement method: display with parameter(s): $name'),
    ];*/

    //create table header
    $header_table = array(
      'id'         => t('#'),
      'first_name' => t('First Name'),
      'last_name'  => t('Last Name'),
      'email'      => t('Email'),
      'phone'      => t('Phone'),
      'question'   => t('Question'),
      'crdate'     => t('Created Date'),
      'opt1'       => t('View'),
      'opt'        => t('Delete'),
    );

//select records from table
    $query = \Drupal::database()->select('usno_subscriber', 'm');
    $query->fields('m', ['id','first_name','last_name','email','phone','question','crdate']);
    $query->orderBy('id', $direction = 'DESC');
     // $results = $query->execute()->fetchAll();

    //For the pagination we need to extend the pagerselectextender and
    //limit in the query
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(10);
    $results = $pager->execute()->fetchAll();

        $rows=array();

    foreach($results as $data){
        $delete = Url::fromUserInput('/admin/subscriber/user/delete/'.$data->id);
        $edit   = Url::fromUserInput('/admin/subscriber/user/add?num='.$data->id);

      //print the data from table
        $rows[] = array(
          'id'         => $data->id,
          'first_name' => $data->first_name,
          'last_name'  => $data->last_name,
          'email'      => $data->email,
          'phone'      => $data->phone,
          'question'   => $data->question,
          'crdate'     => $data->crdate,
          \Drupal::l('View', $edit),
          \Drupal::l('Delete', $delete),
      );
    }
    //display data in site
    $form['table'] = [
            '#type' => 'table',
            '#header' => $header_table,
            '#rows' => $rows,
            '#empty' => t('No users found'),
        ];
    
    // Finally add the pager.
    $form['pager'] = array(
      '#type' => 'pager'
    );

    return $form;
    
  }
}
