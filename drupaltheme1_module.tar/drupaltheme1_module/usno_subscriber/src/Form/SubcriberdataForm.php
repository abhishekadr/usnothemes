<?php

namespace Drupal\usno_subscriber\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Cache\Cache;

/**
 * Class SubcriberdataForm.
 *
 * @package Drupal\usno_subscriber\Form
 */
class SubcriberdataForm extends FormBase {


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'subcriberdata_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $conn = Database::getConnection();
    $record = array();
    if (isset($_GET['num'])) {
        $query = $conn->select('usno_subscriber', 'm')
            ->condition('id', $_GET['num'])
            ->fields('m');
        $record = $query->execute()->fetchAssoc();

    }

    $form['first_name'] = array(
      '#type' => 'textfield',
      '#title' => t('First Name:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['first_name']) && $_GET['num']) ? $record['first_name']:'',
      '#attributes' => array('readonly' => 'readonly'),
    );

    $form['last_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Last Name:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['last_name']) && $_GET['num']) ? $record['last_name']:'',
      '#attributes' => array('readonly' => 'readonly'),
    );

    $form['email'] = array(
      '#type' => 'email',
      '#title' => t('Email:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['email']) && $_GET['num']) ? $record['email']:'',
      '#attributes' => array('readonly' => 'readonly'),
    );

    $form['phone'] = array(
      '#type' => 'textfield',
      '#title' => t('Phone:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['phone']) && $_GET['num']) ? $record['phone']:'',
      '#attributes' => array('readonly' => 'readonly'),
    );

    $form['question'] = array (
      '#type' => 'textarea',
      '#title' => t('Question:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['question']) && $_GET['num']) ? $record['question']:'',
      '#attributes' => array('readonly' => 'readonly'),
      );
    
    // $form['crdate'] = array (
    //    '#type' => 'textfield',
    //   '#title' => t('crdate'),
    //   '#required' => TRUE,
    //   '#default_value' => (isset($record['crdate']) && $_GET['num']) ? $record['crdate']:'',
    //   );

    
    /*$form['submit'] = [
        '#type' => 'submit',
        '#value' => 'save',
        //'#value' => t('Submit'),
    ];*/
    
    $back_btn_link = base_path().'admin/subscriber/user/table';
    $form['cancel'] = array(
      '#type' => 'button',
      '#value' => t('Back'),
      '#button_type' => 'cancel',
      '#submit' => false,
      '#weight' => 1000,
      '#attributes' => array('onclick' => "window.location = '$back_btn_link'; return false;"),
    );

  //   $form['actions']['cancel'] = array(
  //     '#type'   => 'submit',
  //     '#value'  => t('Cancel'),
  //     '#access' => TRUE,
  //     '#weight' => 15,
  //     '#submit' => array('usno_scbscriber_form_cancel', 'node_form_submit_build_node'),
  //     '#limit_validation_errors' => array(),
  //   );
      return $form;
  }


  /**
    * {@inheritdoc}
    */
  public function validateForm(array &$form, FormStateInterface $form_state) {
   parent::validateForm($form, $form_state);
  }

  
  /**
 * Custom cancel button callback.
 */
  public function usno_scbscriber_form_cancel($form, &$form_state) {
  $url = $_GET['destination'] ? $_GET['destination'] : 'choose/your/path';
  drupal_goto($url);
  }
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $field=$form_state->getValues();
   //echo "$name";
    $email=$field['candidate_mail'];
    $is_verify=$field['is_verify'];
    $crdate=date('Y-M-d h:i:s');

    if (isset($_GET['num'])) {
          $field  = array(
              'email' =>  $email,
              'is_verify' => $is_verify,
              'crdate' => $crdate,
          );
          $query = \Drupal::database();
          $query->update('usno_subscriber')
              ->fields($field)
              ->condition('id', $_GET['num'])
              ->execute();
          drupal_set_message("succesfully updated");
          $form_state->setRedirect('usno_subscriber.display_table_controller_display');

      }
      else
      {
           $field= array(
              'email' =>  $email,
              'is_verify' => $is_verify,
              'crdate' => $crdate,
            );
           $query = \Drupal::database();
           $query ->insert('usno_subscriber')
               ->fields($field)
               ->execute();
           drupal_set_message("succesfully saved");
          $form_state->setRedirect('usno_subscriber.display_table_controller_display');
      }
     }

}
